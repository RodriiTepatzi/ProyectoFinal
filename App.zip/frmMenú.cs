﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Diagnostics.Eventing.Reader;

namespace winSemaforos
{
    public partial class frmMenú : Form
    {
        char[] ValoresApagados = new char[] {'a','b','c','d','e','f','h','i'};
        char[] verde1 = new char[] { '1', '4', '7' };
        char[] rojo1 = new char[] { '3', '6', '9' };
        char[] amarillo1 = new char[] { '2', '5', '8' };
        char[] verde2 = new char[] { 'a', 'd', '7' };
        char[] rojo2 = new char[] { 'c', 'f', 'i' };
        char[] amarillo2 = new char[] { 'b', 'e', 'h' };
        int semaforo = 0, semaforo2 = 0, semaforo3 = 0, cverde = 0, camarillo = 0, z = 0, y = 0, crojo = 0, crojo2 = 0,cverde2=0,camarillo2=0, x=0;

        string[] puertosdisponibles = SerialPort.GetPortNames();

        private void tmrSemaforo1_Tick(object sender, EventArgs e)
        {
            if (cverde < 6) // 6 segundos en verde
            {
                encenderLed("v", z, 1);
                cverde++;
            }
            else if (camarillo < 3) // 3 segundos en amarillo después del verde
            {
                encenderLed("v", z, 0);
                encenderLed("a", z, 1);
                camarillo++;
            }
            else if (crojo < 27) // 27 segundos en rojo después del amarillo
            {
                encenderLed("a", z, 0);
                encenderLed("r", z, 1);
                crojo++;
            }
            else if (camarillo2 < 3 && crojo==27) // 3 segundos en amarillo después del rojo
            {
                encenderLed("r", z, 0);
                encenderLed("a", z, 1);
                camarillo2++;
            }
            else // Reinicio del ciclo y apagado de los LEDs
            {
                if (crojo==27)
                {
                    reiniciarContadores(); // Reinicia los contadores cverde, camarillo, crojo y camarillo2 a 0
                    for (int i = 0; i < ValoresApagados.Length; i++)
                    {
                        serialPort1.Write(ValoresApagados[i].ToString());
                    }
                }
                
            }

        }

        private void btnManual_Click(object sender, EventArgs e)
        {
            txtSemaforo1.Enabled = true;
            txtSemaforo2.Enabled=true;
            txtSemaforo3.Enabled=true;
            grbManual.Visible = true;
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            int z=int.Parse(txtSemaforo1.Text);
            int y = int.Parse(txtSemaforo2.Text);
            int x = int.Parse(txtSemaforo3.Text);

            tmrSemaforo1.Enabled = true;
            tmrSemaforo2.Enabled=true;
            tmrSemaforo3.Enabled=true;
        }

        public frmMenú()
        {
            InitializeComponent();
        }

        private void tmrSemaforo2_Tick(object sender, EventArgs e)
        {
            if (crojo <= 10)
            {
                encenderLed("r", y, 1);
                crojo++;
            }
            else if (camarillo <= 3)
            {
                encenderLed("r", y, 0);
                encenderLed("a", y, 1);
                camarillo++;
            }
            else if (cverde <= 6)
            {
                encenderLed("a", y, 0);
                encenderLed("v", y, 1);
                cverde++;
            }
            else if (camarillo2 <= 3)
            {
                encenderLed("v", y, 0);
                encenderLed("a", y, 1);
                camarillo2++;
            }
            else if (crojo2 <= 17)
            {
                encenderLed("a", y, 0);
                encenderLed("r", y, 1);
                crojo2++;
            }
            else
            {
                // Reinicia los contadores y vuelve a empezar el ciclo
                reiniciarContadores();
            }
        }   

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void modorandom()
        {
            List<int> numeros = new List<int> { 1, 2, 3 };

            // Mezclar la lista de números aleatorios
            Random rnd = new Random();
            numeros = numeros.OrderBy(x => rnd.Next()).ToList();

            // Asignar valores a los semáforos
            semaforo = numeros[0];
            semaforo2 = numeros[1];
            semaforo3 = numeros[2];
            if (semaforo==3)
            {
                x = 1;
                
            }
            else
            {
                if(semaforo2==3)
                {
                    x= 2;
                }
                else
                {
                    x = 3;
                }
            }
            if (semaforo==2)
            {
                y = 1;
            }
            else
            {
                if(semaforo2==2)
                {
                    y = 2;
                }
                else
                {
                    y = 3;
                }
            }
            if (semaforo==1)
            {
                z = 1;

            }
            else
            {
                if(semaforo2==1)
                {
                    z = 2;
                }
                else
                {
                    z = 3;
                }
            }
        }
        void reiniciarContadores()
        {
            cverde = 0;
            camarillo = 0;
            crojo = 0; crojo2 = 0;
            cverde2 = 0;
            camarillo2 = 0;
            crojo2 = 0;
        }

        private void btnAbrirPuerto_Click_1(object sender, EventArgs e)
        {
            AbrirPuerto();
            btnAuto.Visible = true;
            btnManual.Visible = true;
           
        }


        private void btnAuto_Click(object sender, EventArgs e)
        {
            modorandom();
            MessageBox.Show($"Semaforos: semaforo 1 {semaforo}, semaforo 2 {semaforo2}, semaforo 3 {semaforo3}");
            for (int i = 0; i < ValoresApagados.Length; i++)
            {
                serialPort1.Write(ValoresApagados[i].ToString());
            }
            tmrSemaforo3.Enabled = true;
            tmrSemaforo2.Enabled = true;
            tmrSemaforo1.Enabled = true;
        }

        void encenderLed(string color, int nsemafoto, int encendido)
        {
            try
            {
                // Determina el índice del LED basado en el semáforo
                int ledIndex = (nsemafoto == 1) ? 0 : (nsemafoto == 2) ? 1 : 2; // Ajusta según tu mapeo

                if (encendido == 1)
                {
                    if (color == "v")
                    {
                        serialPort1.Write(verde1[ledIndex].ToString());
                    }
                    else if (color == "r")
                    {
                        serialPort1.Write(rojo1[ledIndex].ToString());
                    }
                    else if (color == "a")
                    {
                        serialPort1.Write(amarillo1[ledIndex].ToString());
                    }
                }
                else if (encendido == 0)
                {
                    if (color == "v")
                    {
                        serialPort1.Write(verde2[ledIndex].ToString());
                    }
                    else if (color == "r")
                    {
                        serialPort1.Write(rojo2[ledIndex].ToString());
                    }
                    else if (color == "a")
                    {
                        serialPort1.Write(amarillo2[ledIndex].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        void AbrirPuerto()
        {
            //VALIDAR QUE EL COMBO BOX TENGA PUERTOS DETECTADOS
            if (cmbPuertosSeriales.Items.Count >= 1)
            {
                //verificaf que al menos se seleccione al menos un puerto
                if (cmbPuertosSeriales.SelectedIndex != -1)
                {
                    //verificar si no esta abierto el puerto serial
                    if (!serialPort1.IsOpen)
                    {
                        //se asigna el nombre del puerto seleccionado
                        serialPort1.PortName = cmbPuertosSeriales.SelectedItem.ToString();
                        //abre el puerto
                        serialPort1.Open();
                        //asigna la imagen del led apagado
                        
                        MessageBox.Show("el puerto serial se ario correctamente", "abrir el puerto");


                    }
                    else
                    {
                        MessageBox.Show("el puerto ya se encuentra abierto", "abrir el puerto");
                    }
                }
                else
                {
                    MessageBox.Show("debes de seleccionar un puerto para abrirlo", "abrir el puerto");
                }
            }
            else
            {
                MessageBox.Show("no hay puertos seriales disponibles", "abrir el puerto");
            }
        }

        private void tmrSemaforo3_Tick(object sender, EventArgs e)
        {
            //POSICION 3

            if (crojo <= 23)
            {
                encenderLed("r", x, 1); // Enciende el rojo
                crojo++;
            }
            else if (camarillo <= 3)
            {
                encenderLed("r", x, 0); // Apaga el rojo
                encenderLed("a", x, 1); // Enciende el amarillo
                camarillo++;
            }
            else if (cverde <= 6)
            {
                encenderLed("a", x, 0); // Apaga el amarillo
                encenderLed("v", x, 1); // Enciende el verde
                cverde++;
            }
            else if (camarillo2 <= 3)
            {
                encenderLed("v", x, 0); // Apaga el verde
                encenderLed("a", x, 1); // Enciende el amarillo
                camarillo2++;
            }
            else if (crojo2 <= 4)
            {
                encenderLed("a", x, 0); // Apaga el amarillo
                encenderLed("r", x, 1); // Enciende el rojo
                crojo2++;
            }
            else
            {
                // Reiniciar los datos cuando todos los contadores han alcanzado su límite
                if (crojo == 23 && camarillo == 3 && cverde == 6 && camarillo2 == 3 && crojo2 == 4)
                {
                    reiniciarContadores(); // Llama a la función para reiniciar los contadores
                }
            }

        }

        private void frmMenú_Load(object sender, EventArgs e)
        {
            try
            {
                //Limpiar los valores del combobox
                cmbPuertosSeriales.Items.Clear();
                //Verificar si el arreglo tiene por lo menos un valor
                if (puertosdisponibles.Length >= 1)
                {
                    //se recorre el arreglo con los nombres de los puertos seriales
                    //detectados y los asigna al combo.
                    foreach (string puerto in puertosdisponibles)
                    {
                        //agrega el nombre del com o puerto serial al combobox
                        cmbPuertosSeriales.Items.Add(puerto);
                    }
                }
                else
                {
                    //cambia la imagen de led apagado
                    
                    MessageBox.Show("No se detectaron puertos seriales" +
                        "conectados!");
                    cmbPuertosSeriales.Text = "Sin puertos";
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Verificar la conexión con el puerto serial.",
                    "Encender/Apagar el Led!");
            }
        }
    }
}
