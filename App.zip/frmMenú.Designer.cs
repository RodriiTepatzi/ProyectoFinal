﻿namespace winSemaforos
{
    partial class frmMenú
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenú));
            this.lblTítulo = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.picSemáforo = new System.Windows.Forms.PictureBox();
            this.cmbPuertosSeriales = new System.Windows.Forms.ComboBox();
            this.btnAbrirPuerto = new System.Windows.Forms.Button();
            this.lblPuertoSerial = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.lblSemaforo1 = new System.Windows.Forms.Label();
            this.lblSemaforo2 = new System.Windows.Forms.Label();
            this.lblSemaforo3 = new System.Windows.Forms.Label();
            this.txtSemaforo1 = new System.Windows.Forms.TextBox();
            this.txtSemaforo2 = new System.Windows.Forms.TextBox();
            this.txtSemaforo3 = new System.Windows.Forms.TextBox();
            this.tmrSemaforo3 = new System.Windows.Forms.Timer(this.components);
            this.btnManual = new System.Windows.Forms.Button();
            this.grbManual = new System.Windows.Forms.GroupBox();
            this.btnAuto = new System.Windows.Forms.Button();
            this.tmrSemaforo2 = new System.Windows.Forms.Timer(this.components);
            this.tmrSemaforo1 = new System.Windows.Forms.Timer(this.components);
            this.btnActivar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picSemáforo)).BeginInit();
            this.grbManual.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTítulo
            // 
            this.lblTítulo.AutoSize = true;
            this.lblTítulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTítulo.ForeColor = System.Drawing.SystemColors.Info;
            this.lblTítulo.Location = new System.Drawing.Point(225, 1);
            this.lblTítulo.Name = "lblTítulo";
            this.lblTítulo.Size = new System.Drawing.Size(460, 108);
            this.lblTítulo.TabIndex = 0;
            this.lblTítulo.Text = "Semáforo";
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(700, 132);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(80, 29);
            this.btnSalir.TabIndex = 2;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click_1);
            // 
            // picSemáforo
            // 
            this.picSemáforo.Image = ((System.Drawing.Image)(resources.GetObject("picSemáforo.Image")));
            this.picSemáforo.Location = new System.Drawing.Point(-3, 1);
            this.picSemáforo.Name = "picSemáforo";
            this.picSemáforo.Size = new System.Drawing.Size(171, 153);
            this.picSemáforo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSemáforo.TabIndex = 5;
            this.picSemáforo.TabStop = false;
            // 
            // cmbPuertosSeriales
            // 
            this.cmbPuertosSeriales.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPuertosSeriales.FormattingEnabled = true;
            this.cmbPuertosSeriales.Location = new System.Drawing.Point(243, 132);
            this.cmbPuertosSeriales.Name = "cmbPuertosSeriales";
            this.cmbPuertosSeriales.Size = new System.Drawing.Size(442, 60);
            this.cmbPuertosSeriales.TabIndex = 6;
            // 
            // btnAbrirPuerto
            // 
            this.btnAbrirPuerto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAbrirPuerto.Location = new System.Drawing.Point(700, 167);
            this.btnAbrirPuerto.Name = "btnAbrirPuerto";
            this.btnAbrirPuerto.Size = new System.Drawing.Size(80, 27);
            this.btnAbrirPuerto.TabIndex = 7;
            this.btnAbrirPuerto.Text = "Abrir";
            this.btnAbrirPuerto.UseVisualStyleBackColor = false;
            this.btnAbrirPuerto.Click += new System.EventHandler(this.btnAbrirPuerto_Click_1);
            // 
            // lblPuertoSerial
            // 
            this.lblPuertoSerial.AutoSize = true;
            this.lblPuertoSerial.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPuertoSerial.ForeColor = System.Drawing.SystemColors.Info;
            this.lblPuertoSerial.Location = new System.Drawing.Point(274, 195);
            this.lblPuertoSerial.Name = "lblPuertoSerial";
            this.lblPuertoSerial.Size = new System.Drawing.Size(387, 32);
            this.lblPuertoSerial.TabIndex = 8;
            this.lblPuertoSerial.Text = "Puerto(#) Serial detectado (#)";
            // 
            // lblSemaforo1
            // 
            this.lblSemaforo1.AutoSize = true;
            this.lblSemaforo1.Location = new System.Drawing.Point(6, 69);
            this.lblSemaforo1.Name = "lblSemaforo1";
            this.lblSemaforo1.Size = new System.Drawing.Size(125, 26);
            this.lblSemaforo1.TabIndex = 9;
            this.lblSemaforo1.Text = "Semaforo 1";
            // 
            // lblSemaforo2
            // 
            this.lblSemaforo2.AutoSize = true;
            this.lblSemaforo2.Location = new System.Drawing.Point(129, 69);
            this.lblSemaforo2.Name = "lblSemaforo2";
            this.lblSemaforo2.Size = new System.Drawing.Size(125, 26);
            this.lblSemaforo2.TabIndex = 10;
            this.lblSemaforo2.Text = "Semaforo 2";
            // 
            // lblSemaforo3
            // 
            this.lblSemaforo3.AutoSize = true;
            this.lblSemaforo3.Location = new System.Drawing.Point(256, 69);
            this.lblSemaforo3.Name = "lblSemaforo3";
            this.lblSemaforo3.Size = new System.Drawing.Size(125, 26);
            this.lblSemaforo3.TabIndex = 11;
            this.lblSemaforo3.Text = "Semaforo 3";
            // 
            // txtSemaforo1
            // 
            this.txtSemaforo1.Enabled = false;
            this.txtSemaforo1.Location = new System.Drawing.Point(26, 96);
            this.txtSemaforo1.Name = "txtSemaforo1";
            this.txtSemaforo1.Size = new System.Drawing.Size(88, 32);
            this.txtSemaforo1.TabIndex = 12;
            // 
            // txtSemaforo2
            // 
            this.txtSemaforo2.Enabled = false;
            this.txtSemaforo2.Location = new System.Drawing.Point(149, 96);
            this.txtSemaforo2.Name = "txtSemaforo2";
            this.txtSemaforo2.Size = new System.Drawing.Size(88, 32);
            this.txtSemaforo2.TabIndex = 13;
            // 
            // txtSemaforo3
            // 
            this.txtSemaforo3.Enabled = false;
            this.txtSemaforo3.Location = new System.Drawing.Point(276, 96);
            this.txtSemaforo3.Name = "txtSemaforo3";
            this.txtSemaforo3.Size = new System.Drawing.Size(88, 32);
            this.txtSemaforo3.TabIndex = 14;
            // 
            // tmrSemaforo3
            // 
            this.tmrSemaforo3.Interval = 1000;
            this.tmrSemaforo3.Tick += new System.EventHandler(this.tmrSemaforo3_Tick);
            // 
            // btnManual
            // 
            this.btnManual.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManual.Location = new System.Drawing.Point(474, 500);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(338, 75);
            this.btnManual.TabIndex = 15;
            this.btnManual.Text = "Manual";
            this.btnManual.UseVisualStyleBackColor = true;
            this.btnManual.Visible = false;
            this.btnManual.Click += new System.EventHandler(this.btnManual_Click);
            // 
            // grbManual
            // 
            this.grbManual.Controls.Add(this.btnActivar);
            this.grbManual.Controls.Add(this.lblSemaforo2);
            this.grbManual.Controls.Add(this.lblSemaforo1);
            this.grbManual.Controls.Add(this.lblSemaforo3);
            this.grbManual.Controls.Add(this.txtSemaforo3);
            this.grbManual.Controls.Add(this.txtSemaforo1);
            this.grbManual.Controls.Add(this.txtSemaforo2);
            this.grbManual.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbManual.ForeColor = System.Drawing.SystemColors.Info;
            this.grbManual.Location = new System.Drawing.Point(448, 338);
            this.grbManual.Name = "grbManual";
            this.grbManual.Size = new System.Drawing.Size(393, 156);
            this.grbManual.TabIndex = 17;
            this.grbManual.TabStop = false;
            this.grbManual.Text = "Semáforos";
            this.grbManual.Visible = false;
            // 
            // btnAuto
            // 
            this.btnAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAuto.Location = new System.Drawing.Point(130, 500);
            this.btnAuto.Name = "btnAuto";
            this.btnAuto.Size = new System.Drawing.Size(338, 75);
            this.btnAuto.TabIndex = 18;
            this.btnAuto.Text = "Automatico";
            this.btnAuto.UseVisualStyleBackColor = true;
            this.btnAuto.Visible = false;
            this.btnAuto.Click += new System.EventHandler(this.btnAuto_Click);
            // 
            // tmrSemaforo2
            // 
            this.tmrSemaforo2.Interval = 1000;
            this.tmrSemaforo2.Tick += new System.EventHandler(this.tmrSemaforo2_Tick);
            // 
            // tmrSemaforo1
            // 
            this.tmrSemaforo1.Interval = 1000;
            this.tmrSemaforo1.Tick += new System.EventHandler(this.tmrSemaforo1_Tick);
            // 
            // btnActivar
            // 
            this.btnActivar.Location = new System.Drawing.Point(276, 21);
            this.btnActivar.Name = "btnActivar";
            this.btnActivar.Size = new System.Drawing.Size(111, 35);
            this.btnActivar.TabIndex = 15;
            this.btnActivar.Text = "activar";
            this.btnActivar.UseVisualStyleBackColor = true;
            this.btnActivar.Click += new System.EventHandler(this.btnActivar_Click);
            // 
            // frmMenú
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(914, 640);
            this.Controls.Add(this.btnAuto);
            this.Controls.Add(this.grbManual);
            this.Controls.Add(this.btnManual);
            this.Controls.Add(this.lblPuertoSerial);
            this.Controls.Add(this.btnAbrirPuerto);
            this.Controls.Add(this.cmbPuertosSeriales);
            this.Controls.Add(this.picSemáforo);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.lblTítulo);
            this.Name = "frmMenú";
            this.Text = "Semaforo 3";
            this.Load += new System.EventHandler(this.frmMenú_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSemáforo)).EndInit();
            this.grbManual.ResumeLayout(false);
            this.grbManual.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTítulo;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.PictureBox picSemáforo;
        private System.Windows.Forms.ComboBox cmbPuertosSeriales;
        private System.Windows.Forms.Button btnAbrirPuerto;
        private System.Windows.Forms.Label lblPuertoSerial;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label lblSemaforo1;
        private System.Windows.Forms.Label lblSemaforo2;
        private System.Windows.Forms.Label lblSemaforo3;
        private System.Windows.Forms.TextBox txtSemaforo1;
        private System.Windows.Forms.TextBox txtSemaforo2;
        private System.Windows.Forms.TextBox txtSemaforo3;
        private System.Windows.Forms.Timer tmrSemaforo3;
        private System.Windows.Forms.Button btnManual;
        private System.Windows.Forms.GroupBox grbManual;
        private System.Windows.Forms.Button btnAuto;
        private System.Windows.Forms.Timer tmrSemaforo2;
        private System.Windows.Forms.Timer tmrSemaforo1;
        private System.Windows.Forms.Button btnActivar;
    }
}

